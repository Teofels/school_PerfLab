vuser_init()
{
	web_reg_save_param("UserSession",
	                   "LB=userSession\" value=\"",
	                   "RB=\"/>",
	                   LAST);
	
	web_reg_find("Text=Welcome to the Web Tours site",
        LAST );
	
	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	//web_set_sockets_option("SSL_VERSION", "AUTO");

	//web_add_cookie("SRCHUID=V=2&GUID=088FB070B7AC4942BC531FB04A04CF47&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	//web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	//web_add_cookie("MC1=GUID=d9688e1aae334f1ca55c92de55af4efd&HASH=d968&LV=202003&V=4&LU=1584629943228; DOMAIN=iecvlist.microsoft.com");

	//web_add_cookie("SRCHUSR=DOB=20200407; DOMAIN=iecvlist.microsoft.com");

	//web_add_header("UA-CPU", 
	//	"AMD64");

	//web_url("iecompatviewlist.xml", 
	//	"URL=https://iecvlist.microsoft.com/IE11/1478281996/iecompatviewlist.xml", 
	//	"TargetFrame=", 
	//	"Resource=0", 
	//	"RecContentType=text/xml", 
	//	"Referer=", 
	//	"Snapshot=t2.inf", 
	//	"Mode=HTML", 
	//	LAST);

	lr_think_time(1);

	lr_start_transaction("UC01_TR01_Login");

	web_reg_find("Text=Using the menu to the left",
        LAST );
	
	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value={UserSession}", ENDITEM, 
		"Name=username", "Value={Login}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=login.x", "Value=70", ENDITEM, 
		"Name=login.y", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("UC01_TR01_Login",LR_AUTO);
	
	return 0;
}
