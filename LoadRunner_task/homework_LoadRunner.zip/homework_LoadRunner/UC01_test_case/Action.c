Action()
{	
	lr_think_time(10);

	lr_start_transaction("UC01_TR04_Select_flight");

	web_submit_data("reservations.pl_2", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value={RandomOutFlight}", ENDITEM, 
		"Name=numPassengers", "Value={numPass}", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value={RandomTypeOfSeat}", ENDITEM, 
		"Name=seatPref", "Value={RandomSeating_Preference}", ENDITEM, 
		"Name=reserveFlights.x", "Value=33", ENDITEM, 
		"Name=reserveFlights.y", "Value=20", ENDITEM, 
		LAST);

	lr_end_transaction("UC01_TR04_Select_flight",LR_AUTO);

	//lr_think_time(5);

	lr_start_transaction("UC01_TR05_Payment_Details");
	
	web_reg_find("Text=Thank you for booking through Web Tours",
        LAST );

	web_submit_data("reservations.pl_3", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value={fName}", ENDITEM, 
		"Name=lastName", "Value={lName}", ENDITEM, 
		"Name=address1", "Value={streets}", ENDITEM, 
		"Name=address2", "Value={address}", ENDITEM, 
		"Name=pass1", "Value={fName} {lName}", ENDITEM, 
		"Name=creditCard", "Value=1234567890", ENDITEM, 
		"Name=expDate", "Value=11\\22", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value={numPass}", ENDITEM, 
		"Name=seatType", "Value={RandomTypeOfSeat}", ENDITEM, 
		"Name=seatPref", "Value={RandomSeating_Preference}", ENDITEM, 
		"Name=outboundFlight", "Value={RandomOutFlight}", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		"Name=buyFlights.x", "Value=33", ENDITEM, 
		"Name=buyFlights.y", "Value=20", ENDITEM, 
		LAST);

	lr_end_transaction("UC01_TR05_Payment_Details",LR_AUTO);

	//lr_think_time(1);

	
	return 0;
}