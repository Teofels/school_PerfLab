Search()
{
	lr_think_time(10);

	lr_start_transaction("UC01_TR02_Flights");

	
	web_reg_save_param("CityName",
	                   "LB=\">",
	                   "RB=</option>",
	                   "Ord=All",
	                   LAST);
	
	web_reg_save_param("TypeOfSeat",
	                   "LB=name=\"seatType\" value=\"",
	                   "RB=\"",
	                   "Ord=All",
	                   LAST);
	
	web_reg_save_param("Seating_Preference",
	                   "LB=name=\"seatPref\" value=\"",
	                   "RB=\"",
	                   "Ord=All",
	                   LAST);
	
	web_reg_find("Text=Find Flight",
        LAST );
	
	// ������ disign studio
/*Correlation comment - Do not change!  Original value='roundtrip' Name ='.cgifields' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=.cgifields",
		"TagName=input",
		"Extract=name",
		"Type=checkbox",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/reservations.pl*",
		LAST);
	// �����

	web_url("Search Flights Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);
	
	
	lr_save_string(lr_paramarr_random("CityName"),"RandomCity1");
	lr_save_string(lr_paramarr_random("CityName"),"RandomCity2");
	//lr_save_string("Sydney","RandomCity1");
	//lr_save_string("Sydney","RandomCity2");
	
	while (strcmp(lr_eval_string("{RandomCity1}"), lr_eval_string("{RandomCity2}")) == 0){
		lr_save_string(lr_paramarr_random("CityName"),"RandomCity2");
	}	
	
	lr_end_transaction("UC01_TR02_Flights",LR_AUTO);

	//lr_think_time(1);	
	
	lr_save_string(lr_paramarr_random("Seating_Preference"),"RandomSeating_Preference");
	lr_save_string(lr_paramarr_random("TypeOfSeat"),"RandomTypeOfSeat");
	
	
	lr_start_transaction("UC01_TR03_Find_Flight");
	
	web_reg_save_param("outFlight",
	                   "LB=outboundFlight\" value=\"",
	                   "RB=\"",
	                   "Ord=All",
	                   LAST);
	
	web_reg_find("Text=Flight departing from",
        LAST );	

	web_submit_data("reservations.pl",
		"Action=http://localhost:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome",
		"Snapshot=t5.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=depart", "Value={RandomCity1}", ENDITEM,
		"Name=departDate", "Value={depDate}", ENDITEM,
		"Name=arrive", "Value={RandomCity2}", ENDITEM,
		"Name=returnDate", "Value={retDate}", ENDITEM,
		"Name=numPassengers", "Value={numPass}", ENDITEM,
		"Name=seatPref", "Value={RandomSeating_Preference}", ENDITEM,
		"Name=seatType", "Value={RandomTypeOfSeat}", ENDITEM,
		"Name=.cgifields", "Value={.cgifields}", ENDITEM,
		"Name=.cgifields", "Value=seatType", ENDITEM,
		"Name=.cgifields", "Value=seatPref", ENDITEM,
		"Name=findFlights.x", "Value=38", ENDITEM,
		"Name=findFlights.y", "Value=11", ENDITEM,
		LAST);
	
	lr_save_string(lr_paramarr_random("outFlight"),"RandomOutFlight");

	lr_end_transaction("UC01_TR03_Find_Flight",LR_AUTO);
	
	return 0;
}
