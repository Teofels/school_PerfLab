Itenary()
{
	lr_think_time(2);

	lr_start_transaction("UC02_TR02_itenary");
	
	web_reg_save_param("cgifields",
	                   "LB=.cgifields\" value=\"",
	                   "RB=\"",
	                   "Ord=All",
	                   LAST);
	web_reg_save_param("flId",
	                   "LB=name=\"flightID\" value=\"",
	                   "RB=\"",
	                   "Ord=All",
	                   LAST);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);
	
//	lr_save_string(lr_paramarr_random("flightTickets"),"RandomFlightTickets");
//	lr_save_string(lr_paramarr_random("flId"),"RandomFlId");
	lr_save_string(lr_paramarr_random("cgifields"),"randCancelFlight");	

	lr_end_transaction("UC02_TR02_itenary",LR_AUTO);
	
	return 0;
}
