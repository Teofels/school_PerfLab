Action()
{
	int i;

	lr_think_time(8);

	lr_start_transaction("UC02_TR03_cancel");
	
	lr_save_string("", "temp");	
		
	for (i=1;i<=atoi(lr_eval_string("{flId_count}"));i++)
    {
        lr_param_sprintf("temp",
        "%sflightID=%s&",
        lr_eval_string("{temp}"),
        lr_paramarr_idx("flId",i));

        lr_param_sprintf("temp",
        "%s.cgifields=%s&",
        lr_eval_string("{temp}"),
        lr_paramarr_idx("cgifields",i));
    }
	
	lr_save_string(lr_eval_string("{randCancelFlight}=on&{temp}removeFlights.x=47&removeFlights.y=5"), "flBody");
	
	web_custom_request("itinerary.pl", 
		"URL=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		"Body={flBody}",		
		LAST);

//	web_submit_data("itinerary.pl", 
//		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
//		"Method=POST", 
//		"TargetFrame=", 
//		"RecContentType=text/html", 
//		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
//		"Snapshot=t10.inf", 
//		"Mode=HTML", 
//		ITEMDATA, 
//		"Name=1", "Value=on", ENDITEM, 
//		"Name=flightID", "Value=29223562-781-MB", ENDITEM, 
//		"Name=.cgifields", "Value=1", ENDITEM, 
//		"Name=removeFlights.x", "Value=47", ENDITEM, 
//		"Name=removeFlights.y", "Value=5", ENDITEM, 
//		LAST);

	lr_end_transaction("UC02_TR03_cancel",LR_AUTO);

	//lr_think_time(15);	

	return 0;
}